export TMOUT=900
readonly TMOUT
